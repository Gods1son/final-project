﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Final_Condorcet_Winner
{
    class VM:INotifyPropertyChanged
    {
        public string Number
        {
            get { return _number; }
            set { _number = value; NotifyPropertyChanged(); }
        }
        private string _number;
        public bool WinnerKnown { get; set; }
        public bool readAgain { get; set; }
        public const string FILE = "test.txt";
        public VM()
        {
            Winner();
        }
        public void Winner()
        {
            do
            {
                //reading the lines and turning to list
                List<string> readTestFile = File.ReadAllLines(FILE).ToList();

                //splitting the first line of the input to know number of ballots and candidates
                string[] firstLineSplit = readTestFile[0].Split(new char[] { ' ' });
                int Ballots = int.Parse(firstLineSplit[0]);
                int Candidates = int.Parse(firstLineSplit[1]);
                //creating two-dimensional arrays to store the ballots
                int[][] Votes = new int[Ballots][];
                ////
                if (Ballots == 0 && Candidates == 0)
                {
                    readAgain = false;
                }

                for (int i = 0; i < Ballots; i++)
                {
                    Votes[i] = new int[Candidates];
                    for (int j = 0; j < Candidates; j++)
                    {
                        string[] LineSplit = readTestFile[i + 1].Split(new char[] { ' ' });
                        Votes[i][j] = int.Parse(LineSplit[j]);
                    }
                }
                int[] SumOfPosition = new int[Candidates];
                for (int v = 0; v < SumOfPosition.Length; v++)
                {
                    for (int x = 0; x < Ballots; x++)
                    {
                        SumOfPosition[v] += Array.IndexOf(Votes[x], v);
                    }
                }
                Dictionary<int, int> Election = new Dictionary<int, int>();
                foreach (var figure in SumOfPosition)
                {
                    if (Election.ContainsKey(figure))
                        Election[figure]++;
                    else
                        Election[figure] = 1;
                }
                foreach (var condition in Election)
                    if (condition.Value > 1)
                    {
                        _number = "No Winner";
                        WinnerKnown = true;
                    }
                if (WinnerKnown == false)
                {
                    int Find = Array.IndexOf(SumOfPosition, SumOfPosition.Min());
                    _number = Find.ToString() + " is the winner";
                }
            } while (readAgain == true);
      }      




        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
